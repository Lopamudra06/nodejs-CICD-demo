function pattern(num){
    let star =''
    for(let i=0;i<num;i++){
        let space =''
        star = star + '*'
        for(j=num-1; j>i; j--){
            space = space+ ' ' 
        }
        console.log(space+star)
    }
}

function pattern1(num){
    // let star =''
    for(let i=0;i<num;i++){
        let space =''
        // star = star + '*'
        let star = ""
        for(j=num-1; j>i; j--){
            space = space+ ' ' 
        }
        for(k = 0;k<=i;k++){
            star += '*'
        }
        console.log(space+star)
    }
}

pattern1(4)