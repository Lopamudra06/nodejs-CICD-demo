// function lastOccurence(arr){
//     let num={};
//     for(let i=0; i<arr.length; i++){
//         if(arr[i] in num){
//             num[arr[i]]= num[arr[i]] +1;
//         } else {
//             num[arr[i]] = 1;
//         }
//     }

//     for(let i=arr.length-1; i>=0; i--){
//         if(arr[i] in num && num[arr[i]]==1){
//             return arr[i];
//         }
//     }
// }

function altLastOccurence(arr){
    console.log(arr)
    for(let i=arr.length-1; i>=0; i--){
        if(arr[i]!=arr[i-1]){
            return arr[i];
        }
    }
}

function lastOccurence(arr){
    console.log(arr)
    for(let i=arr.length-1; i>=0; i--){
        if(arr[i]==arr[i-1]){
            --i;
        } else {
            return arr[i];
        }
    }
}

//console.log(lastOccurence([1,3,1,3,4,5]));
console.log(lastOccurence([1,1,3,3,4,4,5]))
console.log(lastOccurence([1,1,3,4,4,5,5]))