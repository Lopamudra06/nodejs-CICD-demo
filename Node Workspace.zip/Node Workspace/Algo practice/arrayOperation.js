function arrOperation(arr) {
    console.log('Before Sort')
    for(let i=0; i<arr.length; i++){
        console.log(arr[i])
    }
    arr.sort()
    console.log('After Sort')
    for(let i=0; i<arr.length; i++){
        console.log(arr[i])
    }
}

function evenElements(arr){
    console.log('Even array elements')
    for(let i=0; i<arr.length;i++){
        if(arr[i]%2===0){
            console.log(arr[i])
        }
    }
}

function oddElements(arr){
    console.log('Odd array elements')
    for(let i=0; i<arr.length;i++){
        if(arr[i]%2!==0){
            console.log(arr[i])
        }
    }
}

function reversePrintArr(arr){
    for(let i=arr.length-1;i>=0; i--) {
        console.log(arr[i])
    }
}

function reverseArr(arr){
    let revArr= []

    for(let i=0;i<arr.length;i++){
        //revArr.shift(arr[i])
        revArr.push(arr[arr.length-1 - i])
    }
    console.log(revArr)
}

function reverseInPlace(arr){
    let dummy
    // console.log(arr)
    for(let i=0; i<arr.length/2; i++){
        dummy = arr[i]
        arr[i] = arr[arr.length-1-i]
        arr[arr.length-1-i] = dummy

        //console.log(arr)
    }
    console.log(arr)
}

let arr = [5,2,6,1,3,4]
arrOperation(arr)
evenElements(arr)
oddElements(arr)
reverseInPlace(arr)
