function ranks(arr){
    let rankObj ={};
    let count = 0;
    for(let i=0 ; i<arr.length; i++){
        if(arr[i] in rankObj){
            rankObj[arr[i]]=rankObj[arr[i]]+1;
        } else {
            rankObj[arr[i]]=1;
        }
    }
    // for(let key of Object.keys(rankObj)){
    //     console.log(key)
    // }
    for(let key in rankObj){
        //console.log(key)
        //console.log(rankObj[key])
        if(+key+1 in rankObj){
            count += rankObj[key];
        }
    }
    return count;
}

let arr = [4,4,3,3,1,0];
console.log(ranks(arr));

// let obj = {
//     x:1,
//     y:2,
//     z:3,
// }

// console.log(obj.x);
// console.log(obj['x']);

// let k = 'x';
// console.log(obj[k])