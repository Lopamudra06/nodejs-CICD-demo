function duplicateNum(arr){
     let obj={}

     for(let i=0;i<arr.length;i++){
         obj[arr[i]] = arr[i]
     }
     return Object.keys(obj)
}

console.log(duplicateNum([1,1,1,2,2,3,3]));