function monoArr(arr) {
    //let type = 'inc';
    let monoArr = [];
    let breakPoint = 0;
    let i;
    let type = (arr[1] > arr[0]) ? 'inc' :
        ((arr[1] < arr[0]) ? 'dsc' : 'cons');
    //console.log(type)
    for (i = 1; i < arr.length; i++) {

        if (arr[i - 1] < arr[i]) {
            if (type != 'inc') {
                monoArr.push(i - breakPoint);
                breakPoint = i - 1;
            }
            type = 'inc';
        } else if (arr[i - 1] > arr[i]) {
            if (type != 'dsc') {
                monoArr.push(i - breakPoint);
                breakPoint = i - 1;
            }
            type = 'dsc';
        } else {
            if (type != 'cons') {
                monoArr.push(i - breakPoint);
                breakPoint = i - 1;
            }
            type = 'cons';
        }
        //console.log(type)
    }
    monoArr.push(i - breakPoint);

    let result = monoArr.map(num => (num * (num - 1)) / 2);
    return result;
}

let arr = [2, 2, 3, 3, 3, 3, 2, 1, 4, 3, 2, 1];
console.log(monoArr(arr));