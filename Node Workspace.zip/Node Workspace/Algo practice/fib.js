function fib(num){
    let a=1;
    let b=1;
    let c;
    for(let i=2; i<num; i++){
        c=a+b;
        a=b;
        b=c;
    }
    return c;
}

console.log(fib(5))