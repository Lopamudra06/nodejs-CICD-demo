function factorial(num){

let prod = 1
for(let i=num; i>0;i--){
    prod = prod* i
}
  return prod;  
}

let result = factorial(4);
console.log(result)
