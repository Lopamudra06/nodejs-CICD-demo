let num = 90;
let str = 'Hello'
let boo = false
let noValue;
let value = null;
let bigNumber = 900000000000000n;
let obj = {name: 'lopa'};
let array = [1, 'hello']

console.log('Number: '+ +num)
console.log('String: '+ str)
console.log('Boolean: '+ boo)
console.log('Undefined: '+ noValue)
console.log('Null: '+ value)
console.log('BigInt: '+ bigNumber)
console.log('Object:' + JSON.stringify(obj))
console.log('Array:'+ array)

//console.log(typeof(bigNumber))


