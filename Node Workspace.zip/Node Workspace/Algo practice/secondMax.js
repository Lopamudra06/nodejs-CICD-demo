function secondMax(arr, n){
    for(let j=0; j<n;j++){
        let max = -Infinity
        let pos
        for(let i=j;i<arr.length; i++){
            if(max<arr[i]) {
                max= arr[i]
                pos = i
            }
       }
       arr[pos]= arr[j]
       arr[j]=max
    }
    console.log(arr)
    return arr[n-1]
}

console.log(secondMax([2,30,1,-1,7,9,8],3))
