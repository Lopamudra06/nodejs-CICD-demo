function reverseWord(str){
    let arr = str.split('').reverse().join('');
    return arr
}

console.log(reverseWord('lopamudra sahoo'))