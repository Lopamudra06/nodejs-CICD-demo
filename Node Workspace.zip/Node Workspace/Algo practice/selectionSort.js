function selectionSort(arr) {
    for (let j = 0; j < arr.length; j++) {
        let max = -Infinity
        let pos
        for (let i = j; i < arr.length; i++) {
            if (max < arr[i]) {
                max = arr[i]
                pos = i
            }
        }
        arr[pos] = arr[j]
        arr[j]= max
    }
    console.log(arr)
}

let arr= [2,30,4,10,6]
selectionSort(arr)
console.log(arr)
