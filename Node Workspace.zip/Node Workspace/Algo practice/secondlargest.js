function secondLargest(arr){
    let pos;

for(let j=0;j<2;j++){
    let max= -Infinity;
    for(let i=j;i<arr.length;i++){
        if(max<arr[i]){
            max=arr[i]
            pos= i
        }
    }
    temp = arr[j]
    arr[j] = max
    arr[pos] = temp
}
    return arr[1]
}


console.log(secondLargest([3,1,2,5,6]))