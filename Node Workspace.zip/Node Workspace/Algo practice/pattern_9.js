function pattern(num) {
    let star = ''
    for (let i = 0; i < num; i++) {
        if (i <= num / 2) {
            star = star + '*'
            console.log(star)
        } else {
            star = star.substr(0, star.length - 1)
            console.log(star)
        }
    }
}

pattern(5)