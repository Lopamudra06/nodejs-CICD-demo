function pattern(num){
    let star =''
    let value=''
    for(let i=0; i<num; i++){
        if(i%2 == 0){
            value = '*'
        }
        else {
            value = ' '
        }
        star = star + value
    }
    console.log(star)
}

pattern(7)