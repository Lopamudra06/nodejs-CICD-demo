function rotateArr(arr,n){
    let length = arr.length;
    let index = n%length

    return arr[index]
}

console.log(rotateArr([1,2,3,4,5,6],80))