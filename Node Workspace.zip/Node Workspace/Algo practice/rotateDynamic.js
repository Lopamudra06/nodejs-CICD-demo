function rotateArr(arr, n){
    let length = arr.length;
    for(let i=arr.length-1;i>=0;i--){
        arr[i+n] =arr[i]
    }
    console.log(arr)
    for(let i=length; i<arr.length;i++){
        arr[i%length]=arr[i]
    }
    arr.length=length
    console.log(arr)
}

rotateArr([1,2,3,4,5],3)