let obj = {a:1}

console.log(obj.a)
console.log(obj['a'])
let x= 'a';
console.log(obj[x])
