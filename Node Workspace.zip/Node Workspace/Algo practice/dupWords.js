function dupWords(para){
    let arrOfWords = para.split(' ');
    let obj ={}

    for(let i=0;i<arrOfWords.length;i++){
        obj[arrOfWords[i]] = arrOfWords[i]
    }
    return Object.keys(obj)
}

console.log(dupWords('lorem ipsum lorem ipsum'))