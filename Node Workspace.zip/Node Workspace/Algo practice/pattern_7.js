function pattern(num){
    let space =''
    for(let i=0; i<num; i++){
        let star =''
        for(let j=num-1; j>=i; j--){
            star = star + '*'
        }
        console.log(space + star)
        space = space+ ' '
    }
}

pattern(4)