function checkEven(arr) {
    let count = 0
    let length = arr.length
    let firstCounted = false;
    let lastCounted = false;
    for (let i = 0; i < arr.length-1; i++) {
        if ((arr[i] + arr[i + 1]) % 2 === 0) {
                count++;  
                ++i;
                if(i==0)
                    firstCounted = true;
                if(i+1 == arr.length-1)
                    lastCounted = true;
        }
    }

    if(!firstCounted && !lastCounted && (arr[0]+arr[length-1]%2===0)) {
        count++
    }

    return count
}

console.log(checkEven([5,5,5,5,5]))