"use strict"
let obj={
    'num': 1,
    'str': 'hello',
    'func': function print() {
        console.log('world')
    },
    'arr': [1,2,3,4],
    'obj': {
        'name': 'lopa'
    }
}

for(let keys in obj){
    console.log('keys: '+ keys + ' Value: ' +obj[keys])
}

console.log(Object.values(obj))
console.log(Object.keys(obj))

for(let value of Object.values(obj)){
    console.log(value)
}

for(let key of Object.keys(obj)){
    console.log(key)
}