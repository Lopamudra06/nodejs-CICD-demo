function checkChar(str){
    let eachChar = str.split('')
    let finalStr=''
    for(let i=0; i<eachChar.length;i++){
        if((eachChar[i].charCodeAt(0) >64 && eachChar[i].charCodeAt(0)<91)|| (eachChar[i].charCodeAt(0) >96 && eachChar[i].charCodeAt(0)<123)) {
            finalStr = finalStr + eachChar[i]
        }
    }
    console.log(finalStr)
}

checkChar('lopamudra123')