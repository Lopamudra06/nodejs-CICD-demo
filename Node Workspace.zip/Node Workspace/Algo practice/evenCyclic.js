function evenArr(arr) {
    let count = 0;
    let firstUsed = false, lastUsed = false;
    for (let i = 0; i < arr.length - 1; i++) {
        if ((arr[i] + arr[i + 1]) % 2 == 0) {
            count++;

            if (i == 0) {
                firstUsed = true;
            }
            if (i + 1 == arr.length - 1) {
                lastUsed = true;
            }
            i++;
        }
    }
    //console.log(firstUsed, lastUsed)
    if ((arr[0] + arr[arr.length - 1]) % 2 == 0 && !lastUsed && !firstUsed) {
        count++
    }
    return count;
}
let arr = [5, 4, 5, 5, 5, 5, 5];
console.log(evenArr(arr));