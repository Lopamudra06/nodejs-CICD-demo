function sumArrTarget(numbers, target) {
    let num = {};
    
    for (let i = 0; i < numbers.length; i++) {
        num[numbers[i]] = i;
    }
    console.log(numbers)
    console.log(num);

    for (let i = numbers.length - 1; i >= 0; i--) {
        let j;
        let lookUp;
        lookUp = target - numbers[i];
        if (lookUp in num) {
            j = num[lookUp];
            return [j+1, i+1];
        }
    }
}

console.log(sumArrTarget([2, 7, 11, 15], 9));