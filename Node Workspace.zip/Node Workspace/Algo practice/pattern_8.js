function pattern(num){
    let star = '*'
    for(let i=0; i<=num/2; i++){
        let space =''
        for(let j=num/2; j>i; j--){
            space = space +' '
        }
        console.log(space + star)
        star = star + '**'
    }
}
pattern(7)