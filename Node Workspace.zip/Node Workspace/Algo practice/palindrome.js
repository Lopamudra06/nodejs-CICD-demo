function checkPalindrome(str){
    let arr = str.split('');
    let j= arr.length-1;
    for(let i=0;i<arr.length/2;i++){
        if(arr[i]!==arr[j]){
            return 'Not a palindrome'
        }
        j--;
    }
    return 'palindrome'
}

console.log(checkPalindrome('maaam'))
