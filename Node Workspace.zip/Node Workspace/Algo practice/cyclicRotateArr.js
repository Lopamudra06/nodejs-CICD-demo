function rotateArr(arr){
    let lastItem = arr[arr.length-1]
    let temp

    for(let i=arr.length-1; i>0;i--){
        // temp =arr[i+1]
        arr[i] = arr[i-1]
    }
    arr[0]=lastItem

    return arr
}

console.log(rotateArr([1,2,3,4]))