function reverse(str){
    console.log(str.length);
    let strRev='';

    for(let i=str.length-1; i>=0;i--){
        strRev = strRev + str.charAt(i)
    }
    return strRev
}

console.log(reverse('lopa'))