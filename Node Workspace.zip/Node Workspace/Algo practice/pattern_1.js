/* Print pattern ****** */

function pattern(num){
    let star =''
    for(let i=0; i<num; i++){
        star = star + '*'
    }
    console.log(star)
}

pattern(5)