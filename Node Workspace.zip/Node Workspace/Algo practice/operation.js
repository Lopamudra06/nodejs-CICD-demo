// function operation(num1, num2, str){
//     if(str==='add'){
//         return num1+num2
//     }
//     else if(str==='sub'){
//         return num2-num1
//     }
//     else if(str==='mul'){
//         return num1*num2
//     }
//     else if(str==='div'){
//         if(num1>0){
//             return num2/num1
//         }
//         return 'divison could not perform'
//     }
//     else {
//         return 'not a valid operation'
//     }
// }

// console.log(operation(0,3,'div'))
'use strict';
function operation(a, b, operation) {
    let result
    switch (operation) {
        case 'add':
            result = a + b
            break;
        case 'sub':
            result = b - a
            break;
        case 'mul':
            result = a * b
            break;
        case 'div':
            try {
                result = b / a
            } catch (e) {
                result = 'error' + e
            }
            break;
        default:
            result = 'not a valid operation'
    }
    return result
}

console.log(operation(2, 2, 'add'))