let num = 10;
let boo = false;
let arr = [1,2,3,4];
let bigInt = 90000000000000000000000n;
let obj = {name : 'lopa'}

console.log(num + '')
console.log(boo + '')
console.log(arr + '')
console.log(bigInt + '')
console.log(JSON.stringify(obj))

console.log(+num)
console.log(+boo)
console.log(arr)
