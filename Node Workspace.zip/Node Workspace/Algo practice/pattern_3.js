function pattern(num){
    for(let i=0; i<num; i++){
        let star = ''
        for(let j=0; j<num; j++){
            star = star + '*'
        }
        console.log(star)
    }
}

pattern(4)