let express = require('express');
let s3ActionController = require('../controllers/s3ActionController');
let router = express.Router();

router.post('/addFile',s3ActionController.addFile);
router.delete('/removeFile',s3ActionController.removeFile);
router.get('/getFile',s3ActionController.getFile);

module.exports = router;
