let express = require('express');
let ruleActionController = require('../controllers/ruleActionController');
let router = express.Router();

router.post('/',ruleActionController.addRule);
router.get('/',ruleActionController.getRule);
router.get('/:ruleId',ruleActionController.getRuleById);
router.put('/',ruleActionController.updateRule);
router.delete('/:ruleId',ruleActionController.deleteRuleId);

module.exports = router;