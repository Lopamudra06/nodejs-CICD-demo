//Import packages
let express = require('express');
let AWS = require('aws-sdk');
//let bodyParser = require('body-parser'); @deprecated
let s3ActionRoutes = require('./routes/s3ActionRoutes');
let ruleActionRoutes = require('./routes/ruleActionRoutes');

let port = process.env.PORT || 3000;

//App
let app = express();
app.use(express.json());

//S3 access
AWS.config.getCredentials( (err)=> {
    if(err) {
        console.log(err.stack)
    }
    else {
        console.log('Credentials loaded successfully.')
    }
})

//User routes
app.use('/s3Action',s3ActionRoutes);
app.use('/ruleAction',ruleActionRoutes);

//Starting server
app.listen(port, ()=>{
    console.log('Server is up and running...')
})