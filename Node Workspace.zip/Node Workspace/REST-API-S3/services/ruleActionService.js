let AWS = require('aws-sdk');
let uuid = require('uuid').v4;
const dynamodb = new AWS.DynamoDB({region:'ap-south-1',apiVersion: '2012-08-10'});

exports.addRuleService = async ({metric, minThreshold, maxThreshold,emailID, message}) => {  
    let params = {
        TableName: 'rules',
        Item:{
            rule_id: {S:uuid()},
            metric: {S: metric},
            minThreshold: {N: minThreshold.toString()},
            maxThreshold: {N: maxThreshold.toString()},
            emailID: {S: emailID},
            message: {S: message},
        }
    };

    try {
        await dynamodb.putItem(params).promise();
        return true;
    } catch(error) {
        console.log(error);
        return false;
    }
}

exports.getRuleService = async () => {
    let params = {
        TableName: 'rules'
    }
    try{
        let result = await dynamodb.scan(params).promise();
        return result.Items;
    } catch(error) {
        console.log(error);
        return {response: "Error occured."}
    }
}

exports.getRuleByIdService = async (ruleId) => {
    let params = {
        TableName: 'rules',
        Key: {
           "rule_id" :{S:ruleId}
        }
    }
    try {
        let result =await dynamodb.getItem(params).promise();
        return result.Item || [];
    } catch(error) {
        console.log(error)
        return {response: "Error occured."}
    }
}

exports.updateRuleService = async ({rule_id,metric,minThreshold,maxThreshold,emailID,message}) => {
    let params = {
        TableName: "rules",
        Key: {
            "rule_id":{
                S:rule_id
            }
        },
        ExpressionAttributeNames:{
            "#metric": 'metric',
            "#minT":'minThreshold',
            "#maxT":'maxThreshold',
            "#eid":'emailID',
            "#msg":'message'
        },
        ExpressionAttributeValues:{
            ":m":{
                S:metric
            },
            ":mi":{
                N:minThreshold.toString()
            },
            ":ma":{
                N:maxThreshold.toString()
            },
            ":e":{
                S:emailID
            },
            ":msg":{
                S:message
            }
        },
        ReturnValues: "ALL_NEW",
        UpdateExpression: "SET #metric = :m, #minT = :mi, #maxT = :ma, #eid = :e, #msg = :msg"
    };
    try{
        let returnUpdatedItem = await dynamodb.updateItem(params).promise();
        return returnUpdatedItem.Attributes;
    } catch(error) {
        console.log('Error in update'+ error);
        return {}
    }
}

exports.deleteRuleService = async (ruleId) => {
    let params= {
        TableName : 'rules',
        Key: {
            "rule_id":{S:ruleId}
        }
    }
    try {
        let responseDelete = await dynamodb.deleteItem(params).promise();
        return true;
    } catch(error){
        console.log('Deletion not successful with error '+error);
        return false;
    }
}