const AWS = require('aws-sdk');
const s3 = new AWS.S3({ region: 'ap-south-1' });

exports.checkBucketExists = async (bucketName) => {
    let params = {
        Bucket: bucketName
    };
    try {
        await s3.headBucket(params).promise();
        return true;
    } catch (error) {
        if (error.statusCode === 404) {
            return false;
        }
        throw error;
    }
}

exports.createBucketS3 = async (bucketName) => {
    let params = {
        Bucket: bucketName
    };
    try {
        await s3.createBucket(params).promise();
        console.log('Bucket created successfullly');
        return true
    } catch (error) {
        console.log('Bucket creation failed');
        console.log(error);
        return false;
    }
}

exports.addFileS3 = async (bucketName, fileName, fileContent) => {
    let params = {
        Bucket: bucketName,
        Key: fileName,
        Body: fileContent
    };
    try {
        await s3.putObject(params).promise();
        console.log('File added to the bucket.')
        return true;
    } catch (error) {
        console.log('File can not be added.')
        return false;
    }
};

exports.getFileS3 = async (bucketName, fileName) => {
    let params = {
        Bucket: bucketName,
        Key: fileName
    };
    try {
        let fileContent = await s3.getObject(params).promise();
        return { "fileContent": fileContent.Body.toString() };
    } catch (error) {
        console.log(error)
        return false;
    }
}

exports.removeFileS3 = async (bucketName, fileName) => {
    let params ={
        Bucket: bucketName,
        Key: fileName,
    };
    try {
        await s3.deleteObject(params).promise();
        console.log('File is deleted.')
        return true;

    } catch (error) {
        console.log('File can not be deleted.')
        console.log(error)
        return false;
    }
}

