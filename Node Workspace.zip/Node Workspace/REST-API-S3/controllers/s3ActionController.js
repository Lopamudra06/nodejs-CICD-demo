const s3Services = require('../services/s3ActionService') 

exports.addFile = async (req,res)=> {
    console.log('Add file method called.')
    let body = req.body;
    let bucketExists = false;
    bucketExists = await s3Services.checkBucketExists(body.bucketName);
    console.log(bucketExists);

    if(!bucketExists) {
        let bucketCreated = await s3Services.createBucketS3(body.bucketName);
    }

    let fileAdded = await s3Services.addFileS3(body.bucketName,body.fileName,body.fileContent);
    
    if(fileAdded === true) {
        res.sendStatus(200);
    }
    else {
        res.sendStatus(500);
    }
}

exports.removeFile = async (req,res)=> {
    console.log('Delete file method called.')
    let deleteResponse = await s3Services.removeFileS3(req.query.bucketName, req.query.fileName)
    if(deleteResponse === true) {
        res.send('File removed successfully.')
    } else {
        res.send('File deletion not successful.')
    }
}

exports.getFile = async(req,res)=> {
    console.log('Get file method called.')
    let fileContent = await s3Services.getFileS3(req.query.bucketName, req.query.fileName);
    res.send(fileContent)
}
