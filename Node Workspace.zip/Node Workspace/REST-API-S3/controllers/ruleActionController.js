let service = require('../services/ruleActionService')

exports.addRule = async (req, res) => {
    let ruleAddResponse = await service.addRuleService(req.body);
    let responseObj = {};
    if(ruleAddResponse === true){
        responseObj.message = "Rule added successfully!"
    } else {
        responseObj.message = "Rule couldn't be added!"
    }
    res.json(responseObj);
};

exports.getRule = async (req, res) => {
    let ruleGetResponse = await service.getRuleService();
    res.json(ruleGetResponse);
}

exports.getRuleById = async (req, res) => {
    let ruleId = req.params.ruleId
    let ruleGetResponseById = await service.getRuleByIdService(ruleId);
    res.json(ruleGetResponseById)
}

exports.updateRule = async (req, res) => {
    let ruleUpdateResponse = await service.updateRuleService(req.body)
    res.json(ruleUpdateResponse);
}

exports.deleteRuleId = async (req, res) => {
    let ruleId = req.params.ruleId;
    let responseObj = {};
    let ruleDeleteResponse = await service.deleteRuleService(ruleId);
    if(ruleDeleteResponse){
        responseObj.message ='Item deleted successfully.'
    } else {
        responseObj.message ='Item deletion is not successful.'
    }
    res.json(responseObj)
}
