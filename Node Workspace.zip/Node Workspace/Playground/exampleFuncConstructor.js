function Vehicle(name, maker, engine){
    this.name = name;
    this.maker = maker;
    this.engine = engine;
}

Vehicle.prototype.getDetails = function() {
    console.log(this.name, this.maker, this.engine)
}

let v1 = new Vehicle('Babula', 'Subrat', 'Always ON')

function Machine(){
     this.id = 1000;
}

Vehicle.__proto__ = Machine.prototype;
Machine.prototype.id2 = 2000;
console.log(Vehicle.__proto__)
console.log(Vehicle.prototype)
console.log(v1.__proto__)
console.log(v1.prototype)

