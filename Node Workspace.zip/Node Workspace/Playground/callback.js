// function main_func(file_name, callback){
//     false.readfile(file_name, (err, data)=> {
//         if(err){
//             console.error(err)
//         }else{
//             //calculate sum and count
//             // ....
//             // ....
//             callback(sum, count)
//         }
//     })
// }

// main_func('test.txt', function(sum, count) {
//     console.log(sum, count)
// })

