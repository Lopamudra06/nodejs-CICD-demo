class Vehicle {
    constructor(name, maker, engine){
        this.name = name;
        this.maker = maker;
        this.engine = engine;
    }
    getDetails() {
        return (`The name of the bike is ${this.name}.`)
    }
}

let vehicle = new Vehicle('Hayabusa','Suzuki', '1340cc');
console.log(vehicle.name);
console.log(vehicle.maker);
console.log(vehicle.getDetails());