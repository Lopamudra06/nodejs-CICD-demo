let result = () => {
    return {
        x: 10,
        m1: function () {
            this.y = 20
            return this;
        }
    }
}


let x1 = result().m1();
console.log(x1);