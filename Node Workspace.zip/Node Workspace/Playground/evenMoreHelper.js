module.exports = function(){
    console.log('i am the entire module')
}

