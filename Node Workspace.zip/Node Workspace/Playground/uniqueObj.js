function uniqueElement(arr) {
    let finalArr = [];
    for (let i = 0; i < arr.length; i++) {
        let found = findItem(finalArr, arr[i]);

        if (!found) {
            finalArr.push(arr[i])
        }
    }
    return finalArr
}

function findItem(arr, item) {
    for (ele of arr) {
        if (compareObj(ele, item)) {
            return true;
        }
    }
    return false;
}

function compareObj(obj1, obj2) {
    if (typeof (obj1) === 'Object') {
        for (key in obj1) {
            if (obj1[key] !== obj2[key]) {
                return false;
            }
        }
    } else{
        return obj1 === obj2
        // if(obj1 !== obj2){
        //     return false;
        // }
    }
    return true;
}

let obj1 = { msg: 'Hello' };
let obj2 = { msg: 'Hello' };
let obj3 = { msg: 'Hello1' };
let arr = [obj1, obj2, obj3];
//let arr=[1,2,4,4];
console.log(uniqueElement(arr))

// function findUniqueList(arr){
//     uniqueList = []
//     for(let item of arr){
//         if(!existsInArr(item, uniqueList)){
//             uniqueList.push(item)
//         }
//     }
//     return uniqueList;
// }

// function existsInArr(item , arr){
//     for(let it of arr){
//         if(isEqual(it, item)){
//             return true
//         }
//     }
//     return false
// }

// function isEqual(item1, item2){
//     for(let key in item1){
//         if(item1[key] !== item2[key])
//             return false
//     }
//     return true
// }

// // for(item of arr){
// //     console.log(item)
// // }

// // function uniqueObj(arr){
// //     for(i=0; i<arr.length; i++){
// //         let prev;
// //         for(key in arr[i]){
// //             console.log(arr[i][key]);
// //             if(prev !== arr[i][key]){
// //                 console.log(arr[i][key])
// //             } else {
// //                 prev = arr[i][key];
// //             }
// //         }
// //     }
// // }

// // let obj1 = {msg:'Hello'};
// // let obj2 = {msg:'Hello'};
// // let arr = [obj1, obj2];

// // console.log(uniqueObj(arr));