function doubleAfter2sec(x){
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve(x*2);
        },2000)
    })
}

async function add(x){
    const a = await doubleAfter2sec(10);
    const b = await doubleAfter2sec(20);
    const c = await doubleAfter2sec(30);

    return a+b+c+x;
}

add(10).then(sum=>console.log(sum))