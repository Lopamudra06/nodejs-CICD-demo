const { myPets } = require('./pets');
const { dog, cat } = myPets;

console.log(dog)
console.log(cat)