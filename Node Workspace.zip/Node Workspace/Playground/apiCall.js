let request = require('request')
let util = require('util')

let requestParams = {
    url: 'https://www.7timer.info/bin/astro.php?lon=113.2&lat=23.1&ac=0&unit=metric&output=json&tzshift=0',
    method: 'GET'
}

request(requestParams,(err,data)=>{
    if(err){
        console.log(err)
    } else{
        console.log(JSON.parse(data.body).dataseries[0])
    }
})

let apiGet = util.promisify(request)

apiGet(requestParams).then(data=> console.log(JSON.parse(data.body).dataseries[0]))
                     .catch(err=> console.log(err))