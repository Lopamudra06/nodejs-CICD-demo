let arr = [1,2]
let [first,second] = arr
console.log(first,second)

let a = 1;
let b = 2;

[a, b] = [b, a];
console.log(a, b)


let f1 = 10;
let f2 = 20;
[f1, f2] = [f2, f1];
console.log(f1, f2);
[first, second] = [second, first];
console.log(first, second);