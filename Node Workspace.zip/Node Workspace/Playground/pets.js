const myPets={
    dog:'dream',
    cat:'brown'
};

module.exports={
    myPets
}