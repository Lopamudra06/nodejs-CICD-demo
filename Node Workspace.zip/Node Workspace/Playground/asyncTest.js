/* 1.await can be written inside an async function whereas 
.then can be called on return value of any async function call (i.e.promise)
2. await resolves the promise that is returned by async function and returns the value whereas
.then resolves the return value of async function by calling a callback which gices the value
3. await stops of the execution of further code till the processing of the async process is done whereas
.then executes the code in sequence until the promise is resolved and callback function called 
to get the result*/

async function double(x){
 return x*2;
}
let result = double(2);

result.then(data=>console.log(data))
console.log(result)

let newResult = async function() {
    let data = await double(3);
    console.log( data)
    return data
}
console.log(newResult().then(data=>console.log(data)))
// newResult()

