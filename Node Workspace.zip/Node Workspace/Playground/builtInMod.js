/* IMportant node js built in modules : 1. fs - The file system or fs module can be used to read files, write to files, and append files
                                        2. path - The path module is quite helpful for working with file paths, extending file paths, and determining types of paths.
                                        3. process - accepting command line arguments (argv) and listening for specific events (on).  Instead of importing this module, 
                                        process is a reserved keyword in Node that we can use! ex - process.env
                                        4. http - allows you to create a server and issue HTTP requests and responses.
*/                                    
// const fs= require('fs');
// fs.readFile('someFile.txt',(err,data)=>{
//     if(err){
//         console.log(err)
//     } else {
//         console.log(data.toString())
//     }
// })

// const path = require("path");
// // Normalize a path
// console.log(path.normalize("/test/test1//2slashes/1slash/tab/..")); // /test/test1/2slashes/1slash
// // Join multiple paths together
// console.log(path.join("/first", "second", "something", "then", "..")); // /first/second/something
// // Resolve a path (find the absolute path)
// console.log(path.resolve("first.js"));
// // Find the extention of a filename
// console.log(path.extname("main.js")); // .js

let argValues = process.argv
console.log(argValues[2], argValues[3], argValues[4]);

