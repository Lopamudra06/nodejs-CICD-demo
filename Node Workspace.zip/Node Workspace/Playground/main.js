/*We used the module.exports object to send an object from one file (helpers.js) to another (main.js).*/

let helper = require('./helper')
let moreHelper = require('./moreHelper')
let evenMoreHelper = require('./evenMoreHelper')

helper.sayHi();

console.log(moreHelper.firstName);
moreHelper.sayHello();
moreHelper.sayGoodbye();

evenMoreHelper();

let result = process.argv.slice(2);
console.log(result['name'])

