let event = require('events')
let eventEmitter = new event.EventEmitter();

let connectHandler = function(){
    console.log('connection successful')

    eventEmitter.emit('data received')
}

eventEmitter.on('data received', function(){
    console.log('update this event')
})

connectHandler()