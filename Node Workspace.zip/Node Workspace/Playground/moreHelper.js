/* exports is just a shorthand syntax for module.exports. Rather than wrapping everything inside module.export object,we can attach values to the exports object.*/

exports.sayHello = function(){
    console.log('Hello')
}

exports.sayGoodbye = function(){
    console.log('Goodbye')
}

exports.firstName = 'Elie';