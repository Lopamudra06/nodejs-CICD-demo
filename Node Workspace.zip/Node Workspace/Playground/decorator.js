let name1 = {
    firstName: 'Lopamudra',
    lastName: 'Sahoo',
}

let printFullName = function(homeTown, state){
    console.log(this.firstName + ' ' + this.lastName + ' from ' + homeTown + ' ' + state);
}

printFullName.call(name1, 'Paradeep', 'Odisha')

let name2 = {
    firstName: 'Subrat',
    lastName: 'Sahu',
}

// function borrowing - we can use the function of another object and use in the current object

printFullName.call(name2, 'Jeypore', 'Odisha');

printFullName.apply(name2, ['Jeypore','Odisha']);

// bind method - binds the method to your object and keep the copy of the function
// which can be invoked later.
let printMyName = printFullName.bind(name2, 'Jeypore', 'Odisha');
console.log(printMyName);
printMyName();

