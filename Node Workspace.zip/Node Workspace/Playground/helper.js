module.exports = {
    name: 'lopa',
    sayHi: function(){
        console.log(`Hi ${this.name}`)
    }
};