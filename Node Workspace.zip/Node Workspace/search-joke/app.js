const fs = require('fs');
const request = require('request');

let searchKey = process.argv;
let final;

//console.log(searchKey[2]);

request(`https://icanhazdadjoke.com/search?term=${searchKey[2]}`, { json: true }, (err, data) => {
    if (err) {
        console.log(err);
    } else {
        let arrOfJokes = data.body.results;
        if (arrOfJokes.length < 1) {
            console.log('No jokes found for the search term.')
        } else {
            //console.log(arrOfJokes)
            final = arrOfJokes.reduce((accum, eachJoke) => {
                //console.log(eachJoke.joke)
                accum += eachJoke.joke + '\n';
                //console.log(accum)
                return accum
            }, '')
            // console.log(final)

            fs.writeFile('jokes.txt', final , (err) => {
                if (err) {
                    console.log(err)
                } else {
                    console.log('File written successfully');
                }
            })

        }
    }
})